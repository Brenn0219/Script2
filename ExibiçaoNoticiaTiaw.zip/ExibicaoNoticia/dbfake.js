var db = { //estrutura de dados
    noticia: [
        {
            titulo: 'Globo',
            texto: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',
            imagem: 'http://lorempixel.com.br/600/300/?1',
            categoria: 'Informação',
            data: '23/05/2022'
        }, {
            titulo: 'G1',
            texto: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',            imagem: 'http://lorempixel.com.br/200/100?2',
            imagem: 'http://lorempixel.com.br/600/300/?2',
            categoria: 'Dica',
            data: '23/05/2022'
        }, {
            titulo: 'Jornal Nascional',
            texto: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',            imagem: 'http://lorempixel.com.br/200/100?3',
            imagem: 'http://lorempixel.com.br/600/300/?3',
            categoria: 'Auto-Ajuda',
            data: '23/05/2022'
        }, {
            titulo: 'iSenior',
            texto: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',            imagem: 'http://lorempixel.com.br/200/100?4 ',
            imagem: 'http://lorempixel.com.br/600/300/?4',
            categoria: 'Informação',
            data: '23/05/2022'
        },{
            titulo: 'Jornal Nascional',
            texto: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',            imagem: 'http://lorempixel.com.br/200/100?3',
            imagem: 'http://lorempixel.com.br/600/300/?5',
            categoria: 'Auto-Ajuda',
            data: '23/05/2022'
        }
    ]
}

